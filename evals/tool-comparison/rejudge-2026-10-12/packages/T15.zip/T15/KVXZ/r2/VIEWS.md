# KVXZ · r2

- tile.png.view.png: the image at its real size, 1024×1024
- tile.svg.render.png: the vector drawn by Chromium at 1600×1600 on white (its own size is 1024×1024; vector, so this is sharp, not enlarged)
- preview-3x3.png.overview.png: reduced to 1600×1600 from 3072×3072 (judge detail on the crops)
- preview-3x3.png.crop-1-1.png: 1:1 pixels, x 318–1218, y 318–1218
- preview-3x3.png.crop-1-2.png: 1:1 pixels, x 1854–2754, y 318–1218
- preview-3x3.png.crop-2-1.png: 1:1 pixels, x 318–1218, y 1854–2754
- preview-3x3.png.crop-2-2.png: 1:1 pixels, x 1854–2754, y 1854–2754
- mug-wrap.png.overview.png: reduced to 1600×659 from 2550×1050 (judge detail on the crops)
- mug-wrap.png.crop-1-1.png: 1:1 pixels, x 187–1087, y 75–975
- mug-wrap.png.crop-1-2.png: 1:1 pixels, x 1462–2362, y 75–975
