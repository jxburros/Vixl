# T15 · round 2 request

> Make all the shells amber, and reduce the number of motifs by about a third. Regenerate every file.
