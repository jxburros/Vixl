# T14 · round 2 request

> Shift every lyric 0.25 s earlier (the title card still starts at 0), and make chorus lines 25 % larger.
