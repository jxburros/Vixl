# TJZS · r2

- lighthouse.mp4.frames.png: 12 frames at evenly spaced times (open the MP4 in files/ to watch it)
- lighthouse.mp4.mid-frame.view.png: the image at its real size, 1280×720
