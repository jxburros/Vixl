# VAHU · r1

- instagram-square.png.view.png: the image at its real size, 1080×1080
- instagram-story.png.overview.png: reduced to 900×1600 from 1080×1920 (judge detail on the crops)
- instagram-story.png.crop-1-1.png: 1:1 pixels, x 90–990, y 30–930
- instagram-story.png.crop-2-1.png: 1:1 pixels, x 90–990, y 990–1890
- x-post.png.view.png: the image at its real size, 1600×900
- facebook-event.png.overview.png: reduced to 1600×838 from 1920×1005 (judge detail on the crops)
- facebook-event.png.crop-1-1.png: 1:1 pixels, x 30–930, y 52–952
- facebook-event.png.crop-1-2.png: 1:1 pixels, x 990–1890, y 52–952
- leaderboard.png.view.png: the image at its real size, 728×90
- email-header.png.view.png: the image at its real size, 600×200
