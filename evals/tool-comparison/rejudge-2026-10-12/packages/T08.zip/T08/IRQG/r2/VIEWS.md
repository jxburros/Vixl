# IRQG · r2

- infographic.png.overview.png: reduced to 1067×1600 from 1200×1800 (judge detail on the crops)
- infographic.png.crop-1-1.png: 1:1 pixels, x 150–1050, y 0–900
- infographic.png.crop-2-1.png: 1:1 pixels, x 150–1050, y 900–1800
- infographic.svg.render.png: the vector drawn by Chromium at 1067×1600 on white (its own size is 1200×1800; vector, so this is sharp, not enlarged)
- infographic.pdf.page-1.png: PDF page 1 at 100 dpi (1250×1875)
- infographic.pdf.page-1.300dpi.crop-1-1.png: 1:1 pixels, x 487–1387, y 956–1856
- infographic.pdf.page-1.300dpi.crop-1-2.png: 1:1 pixels, x 2362–3262, y 956–1856
- infographic.pdf.page-1.300dpi.crop-2-1.png: 1:1 pixels, x 487–1387, y 3768–4668
- infographic.pdf.page-1.300dpi.crop-2-2.png: 1:1 pixels, x 2362–3262, y 3768–4668
