# T08 · round 2 request

> December's numbers were wrong. The correct values are flat_white 1480, drip 1120, cold_brew 90, tea 640. Update every chart and number, and change tea's color to plum `#6b3f69`.
