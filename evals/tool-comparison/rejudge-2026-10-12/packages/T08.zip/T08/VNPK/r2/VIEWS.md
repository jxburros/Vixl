# VNPK · r2

- infographic.png.overview.png: reduced to 1067×1600 from 1200×1800 (judge detail on the crops)
- infographic.png.crop-1-1.png: 1:1 pixels, x 150–1050, y 0–900
- infographic.png.crop-2-1.png: 1:1 pixels, x 150–1050, y 900–1800
- infographic.svg.render.png: the vector drawn by Chromium at 1067×1600 on white (its own size is 864×1296; vector, so this is sharp, not enlarged)
- infographic.pdf.page-1.png: PDF page 1 at 100 dpi (1200×1800)
- infographic.pdf.page-1.300dpi.crop-1-1.png: 1:1 pixels, x 450–1350, y 900–1800
- infographic.pdf.page-1.300dpi.crop-1-2.png: 1:1 pixels, x 2250–3150, y 900–1800
- infographic.pdf.page-1.300dpi.crop-2-1.png: 1:1 pixels, x 450–1350, y 3600–4500
- infographic.pdf.page-1.300dpi.crop-2-2.png: 1:1 pixels, x 2250–3150, y 3600–4500
