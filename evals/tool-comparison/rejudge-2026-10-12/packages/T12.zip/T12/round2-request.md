# T12 · round 2 request

> Make it 8 seconds: slow the beam to half speed, change the tagline to "Open daily from 7 am", and extend the final hold to 3 seconds. Same files and specs otherwise.
