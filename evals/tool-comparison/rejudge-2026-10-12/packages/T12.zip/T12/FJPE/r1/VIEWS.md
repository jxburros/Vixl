# FJPE · r1

- intro.mp4.frames.png: 12 frames at evenly spaced times (open the MP4 in files/ to watch it)
- intro.mp4.mid-frame.view.png: the image at its real size, 1080×1080
- intro.gif.frames.png: 12 of 176 frames, evenly spaced (open the GIF in files/ to play it)
- intro.gif.first-frame.view.png: the image at its real size, 540×540
- intro-last-frame.png.view.png: the image at its real size, 1080×1080
