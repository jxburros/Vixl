# FKJR · r2

- menu.pdf.page-1.png: PDF page 1 at 100 dpi (850×1400)
- menu.pdf.page-1.300dpi.crop-1-1.png: 1:1 pixels, x 187–1087, y 600–1500
- menu.pdf.page-1.300dpi.crop-1-2.png: 1:1 pixels, x 1462–2362, y 600–1500
- menu.pdf.page-1.300dpi.crop-2-1.png: 1:1 pixels, x 187–1087, y 2700–3600
- menu.pdf.page-1.300dpi.crop-2-2.png: 1:1 pixels, x 1462–2362, y 2700–3600
- menu-preview.png.overview.png: reduced to 971×1600 from 1275×2100 (judge detail on the crops)
- menu-preview.png.crop-1-1.png: 1:1 pixels, x 187–1087, y 75–975
- menu-preview.png.crop-2-1.png: 1:1 pixels, x 187–1087, y 1125–2025
