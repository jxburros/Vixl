# T16 · round 2 request

> Raise every coffee price by $0.25, remove "Drip refill", and add a note under the Coffee section: "Oat milk +$0.75".
