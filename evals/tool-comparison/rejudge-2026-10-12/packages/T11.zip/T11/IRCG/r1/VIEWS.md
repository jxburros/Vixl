# IRCG · r1

- sketch-clean.png.overview.png: reduced to 1600×1188 from 2000×1485 (judge detail on the crops)
- sketch-clean.png.crop-1-1.png: 1:1 pixels, x 50–950, y 292–1192
- sketch-clean.png.crop-1-2.png: 1:1 pixels, x 1050–1950, y 292–1192
- sketch-lines.svg.render.png: the vector drawn by Chromium at 1600×1188 on white (its own size is 2000×1485; vector, so this is sharp, not enlarged)
- sketch-color.png.overview.png: reduced to 1600×1188 from 2000×1485 (judge detail on the crops)
- sketch-color.png.crop-1-1.png: 1:1 pixels, x 50–950, y 292–1192
- sketch-color.png.crop-1-2.png: 1:1 pixels, x 1050–1950, y 292–1192
- compare.png.overview.png: reduced to 1600×617 from 2799×1080 (judge detail on the crops)
- compare.png.crop-1-1.png: 1:1 pixels, x 249–1149, y 90–990
- compare.png.crop-1-2.png: 1:1 pixels, x 1649–2549, y 90–990
