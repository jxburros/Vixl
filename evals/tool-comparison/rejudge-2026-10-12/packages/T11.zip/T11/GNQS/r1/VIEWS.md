# GNQS · r1

- sketch-clean.png.overview.png: reduced to 1600×1226 from 2000×1532 (judge detail on the crops)
- sketch-clean.png.crop-1-1.png: 1:1 pixels, x 50–950, y 316–1216
- sketch-clean.png.crop-1-2.png: 1:1 pixels, x 1050–1950, y 316–1216
- sketch-lines.svg.render.png: the vector drawn by Chromium at 1600×1226 on white (its own size is 2000×1532; vector, so this is sharp, not enlarged)
- sketch-color.png.overview.png: reduced to 1600×1226 from 2000×1532 (judge detail on the crops)
- sketch-color.png.crop-1-1.png: 1:1 pixels, x 50–950, y 316–1216
- sketch-color.png.crop-1-2.png: 1:1 pixels, x 1050–1950, y 316–1216
- compare.png.overview.png: reduced to 1600×620 from 4060×1572 (judge detail on the crops)
- compare.png.crop-1-1.png: 1:1 pixels, x 565–1465, y 336–1236
- compare.png.crop-1-2.png: 1:1 pixels, x 2595–3495, y 336–1236
