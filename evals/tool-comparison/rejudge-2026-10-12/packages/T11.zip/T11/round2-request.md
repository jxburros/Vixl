# T11 · round 2 request

> Make the roof red `#c0392b` instead of coral, and add a chimney on the right side of the roof, drawn with the same line weight and character as the rest.
