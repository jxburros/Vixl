# WBJG · r2

- keeper-sheet.png.view.png: the image at its real size, 256×32
- keeper-idle.gif.frames.png: 2 of 2 frames, evenly spaced (open the GIF in files/ to play it)
- keeper-idle.gif.first-frame.view.png: the image at its real size, 256×256
- keeper-walk.gif.frames.png: 4 of 4 frames, evenly spaced (open the GIF in files/ to play it)
- keeper-walk.gif.first-frame.view.png: the image at its real size, 256×256
- keeper-wave.gif.frames.png: 2 of 2 frames, evenly spaced (open the GIF in files/ to play it)
- keeper-wave.gif.first-frame.view.png: the image at its real size, 256×256
