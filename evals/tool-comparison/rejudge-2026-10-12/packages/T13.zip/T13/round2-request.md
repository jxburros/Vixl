# T13 · round 2 request

> Make the raincoat red, and add a 2-frame "wave" animation (250 ms per frame) after the walk frames: the sheet becomes 256 × 32, the JSON gains the frames, and add `keeper-wave.gif`.
