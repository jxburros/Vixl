# SPAN · r2

- post.png.view.png: the image at its real size, 1080×1350
- story.png.overview.png: reduced to 900×1600 from 1080×1920 (judge detail on the crops)
- story.png.crop-1-1.png: 1:1 pixels, x 90–990, y 30–930
- story.png.crop-2-1.png: 1:1 pixels, x 90–990, y 990–1890
