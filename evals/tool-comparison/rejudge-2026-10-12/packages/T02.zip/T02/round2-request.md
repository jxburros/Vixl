# T02 · round 2 request

> The date moved: the third line is now "Thursday, November 19 · 7–10 pm". Add the line "Hosted by Mara Quinn" directly under the headline. Then make a 1080 × 1920 story version, `story.png`, with the same content, keeping all text out of the top 250 px and bottom 250 px.
