# T07 · round 2 request

> Add an 11th badge: Iris, Van der Berg, Speaker, Lowtide Labs. Change the Sponsor color to plum `#6b3f69`. Regenerate every badge and the print PDF.
