# XMNM · r1

- coast-edited.jpg.view.png: the image at its real size, 1512×1008
- coast-instagram.jpg.view.png: the image at its real size, 1080×1350
- coast-caption.png.view.png: the image at its real size, 1600×900
