# WLRN · r2

- poster-print.pdf.page-1.png: PDF page 1 at 100 dpi (1125×1725)
- poster-print.pdf.page-1.300dpi.crop-1-1.png: 1:1 pixels, x 393–1293, y 843–1743
- poster-print.pdf.page-1.300dpi.crop-1-2.png: 1:1 pixels, x 2081–2981, y 843–1743
- poster-print.pdf.page-1.300dpi.crop-2-1.png: 1:1 pixels, x 393–1293, y 3431–4331
- poster-print.pdf.page-1.300dpi.crop-2-2.png: 1:1 pixels, x 2081–2981, y 3431–4331
- poster-preview.png.overview.png: reduced to 1035×1600 from 1650×2550 (judge detail on the crops)
- poster-preview.png.crop-1-1.png: 1:1 pixels, x 375–1275, y 187–1087
- poster-preview.png.crop-2-1.png: 1:1 pixels, x 375–1275, y 1462–2362
