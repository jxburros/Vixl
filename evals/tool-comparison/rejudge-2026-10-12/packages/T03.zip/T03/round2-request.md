# T03 · round 2 request

> Change the kicker to "Old Customs House Square". Replace "Live brass band" with "Fire dancers at 8 pm". Add a 1 × 1 in white square with the letters "QR" centered in it, inside the bottom-right corner of the safe area. Same print spec as before.
