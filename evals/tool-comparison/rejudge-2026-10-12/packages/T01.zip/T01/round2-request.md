# T01 · round 2 request

> Make it night: darken the sky but keep it a gradient, and make the beam brighter. Move the lighthouse and its rocks to the right half, with the beam now sweeping left across the sea. Add a third sailboat. Keep everything else exactly as it was.
