# ZUKB · r1

- picture.png.overview.png: reduced to 1600×1067 from 2400×1600 (judge detail on the crops)
- picture.png.crop-1-1.png: 1:1 pixels, x 150–1050, y 350–1250
- picture.png.crop-1-2.png: 1:1 pixels, x 1350–2250, y 350–1250
