# T05 · round 2 request

> Q4 was under-counted: it is 9,250, so the year's total is 35,630 cups. Update the chart and every place the total appears. Then add a slide after "By the numbers", titled "Our regulars", with the quote “Best flat white on the coast.” — Jo, regular since 2019. Use the same style, and give it speaker notes.
