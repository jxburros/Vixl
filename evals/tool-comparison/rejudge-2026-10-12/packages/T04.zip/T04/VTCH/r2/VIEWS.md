# VTCH · r2

- logo-horizontal.svg.render.png: the vector drawn by Chromium at 1600×412 on white (its own size is 1554×400; vector, so this is sharp, not enlarged)
- logo-stacked.svg.render.png: the vector drawn by Chromium at 1600×880 on white (its own size is 1140×627; vector, so this is sharp, not enlarged)
- mark.svg.render.png: the vector drawn by Chromium at 1600×1600 on white (its own size is 512×512; vector, so this is sharp, not enlarged)
- mark-mono.svg.render.png: the vector drawn by Chromium at 1600×1600 on white (its own size is 512×512; vector, so this is sharp, not enlarged)
- favicon.ico.16px.view.png: the image at its real size, 16×16
- favicon.ico.16px.enlarged-x32-nearest.png: the 16×16 image enlarged ×32 with hard pixels, over a checkerboard where it is transparent
- favicon.ico.32px.view.png: the image at its real size, 32×32
- favicon.ico.32px.enlarged-x16-nearest.png: the 32×32 image enlarged ×16 with hard pixels, over a checkerboard where it is transparent
- favicon.ico.48px.view.png: the image at its real size, 48×48
- favicon.ico.48px.enlarged-x10-nearest.png: the 48×48 image enlarged ×10 with hard pixels, over a checkerboard where it is transparent
- app-icon-1024.png.view.png: the image at its real size, 1024×1024
- logo-sheet.png.view.png: the image at its real size, 1600×1200
