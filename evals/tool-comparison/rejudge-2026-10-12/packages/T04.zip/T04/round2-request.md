# T04 · round 2 request

> Rename the business "Tidewick & Co." and change the tagline to "Coffee · Bakery · Harbor". Update every file.
