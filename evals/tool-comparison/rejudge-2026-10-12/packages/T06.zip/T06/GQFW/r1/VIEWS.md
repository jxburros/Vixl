# GQFW · r1

- signup-form.pdf.page-1.png: PDF page 1 at 100 dpi (850×1100)
- signup-form.pdf.page-1.300dpi.crop-1-1.png: 1:1 pixels, x 187–1087, y 375–1275
- signup-form.pdf.page-1.300dpi.crop-1-2.png: 1:1 pixels, x 1462–2362, y 375–1275
- signup-form.pdf.page-1.300dpi.crop-2-1.png: 1:1 pixels, x 187–1087, y 2025–2925
- signup-form.pdf.page-1.300dpi.crop-2-2.png: 1:1 pixels, x 1462–2362, y 2025–2925
- signup-sample.pdf.page-1.png: PDF page 1 at 100 dpi (850×1100)
- signup-sample.pdf.page-1.300dpi.crop-1-1.png: 1:1 pixels, x 187–1087, y 375–1275
- signup-sample.pdf.page-1.300dpi.crop-1-2.png: 1:1 pixels, x 1462–2362, y 375–1275
- signup-sample.pdf.page-1.300dpi.crop-2-1.png: 1:1 pixels, x 187–1087, y 2025–2925
- signup-sample.pdf.page-1.300dpi.crop-2-2.png: 1:1 pixels, x 1462–2362, y 2025–2925
