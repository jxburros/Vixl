# T06 · round 2 request

> Add a required text field `instagram`, labeled "Instagram handle", right after Email. Change the slot options to 30-minute slots: 7:00–7:30, 7:30–8:00, 8:00–8:30, 8:30–9:00, 9:00–9:30, 9:30–10:00. Keep the tab order in reading order. Re-make the sample with slot 8:30–9:00 and instagram @driftwoodquartet.
