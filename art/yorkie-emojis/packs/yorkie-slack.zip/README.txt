Unzip, then open Slack’s emoji picker → Add Emoji → Upload Image. Select a PNG and use its filename as the name. Your workspace must allow custom emoji.

See manifest.json for Unicode mappings and licenses.
VIXL Line is adapted from OpenMoji 17.0.0 (https://openmoji.org), CC BY-SA 4.0.
Changes: softened geometric contours, navy outlines, reduced stroke width and a restrained palette; national flag colors preserved.
VIXL Originals (faces, reactions and everyday symbols) are original VIXL artwork under CC BY-SA 4.0; see per-entry source_origin.
Custom artwork retains the license stated in manifest.json.
Made with Vixl.
