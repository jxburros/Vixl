Unzip, then open Server Settings → Emoji → Upload Emoji and select files from png/. You need Create Expressions or Manage Expressions permission. Server emoji slots and use outside the server depend on the server and your Discord plan.

See manifest.json for Unicode mappings and licenses.
VIXL Line is adapted from OpenMoji 17.0.0 (https://openmoji.org), CC BY-SA 4.0.
Changes: softened geometric contours, navy outlines, reduced stroke width and a restrained palette; national flag colors preserved.
VIXL Originals (faces, reactions and everyday symbols) are original VIXL artwork under CC BY-SA 4.0; see per-entry source_origin.
Custom artwork retains the license stated in manifest.json.
Made with Vixl.
